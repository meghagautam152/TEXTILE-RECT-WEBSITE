import React,{Component} from 'react';
import _ from 'underscore';
export default class LetsGetStarted extends Component{

  constructor(props){
    
      super();
      this.state = {
        productCategory:[{
          productId:2,
          name:"ROC Compliance for Pvt ltd"
        },
        {
          productId:2,
          name:"ROC compliance for One person company"
        },
        {
          productId:2,
          name:"ROC compliance for LLP"
        },
        {
          productId:2,
          name:"Compliance Package for Pvt Ltd"
        },
        {
          productId:2,
          name:"Compliance Package for One Person company"
        },
        {
          productId:2,
          name:"Compliance Package  for LLP"
        },
        {
          productId:2,
          name:"Appointment for  Director"
        },
        {
          productId:2,
          name:"Resignation for  Director"
        },
        {
          productId:2,
          name:"Change in  Name"
        },
        {
          productId:2,
          name:"Change in Registered Address"
        },
        {
          productId:2,
          name:"Compliance Package  for LLP"
        },
        {
          productId:2,
          name:"Alteration of Share Capital"
        },
        {
          productId:3,
          name:"GST Registration"
        },
        {
          productId:3,
          name:"GST Migration"
        },
        {
          productId:3,
          name:"GST Compliance"
        },
        {
          productId:3,
          name:"TDS Compliance"
        },
        {
          productId:3,
          name:"Income Tax Compliance"
        },
        
       ],
        product:[{
          productId:1,
          name:"Incorporate+",
       },
       {
        productId:2,
        name:"Comply+",
      },
      {
        productId:3,
        name:"Tax+"
      },
      {
        productId:4,
        name:"Protect+"
      }],

       selectedproductid:2,
       filteredCategory:[],
          };
       this.filterproduct=this.filterproduct.bind(this);
          }           
           
          

          filterproduct( product ){
            var productCategory=this.state.productCategory;
            console.log(this.state.filteredCategory);
           
           /* this.setState({selectedproductid:product.target.value})*/
        this.state.filteredCategory=_.where(productCategory, {productId:product.target.value});
                 

        console.log(this.state.filteredCategory,"after");
        alert( this.state.selectedproductid);
        
            

          }

  



 
  render(){
    return(
      <div className="col-lg-4 dialogue1">
        <form name="contactForm" id="contactForm">
          <h5 className="text-center dialoguetext"> {"Let's get started"}</h5>

          <div className="control-group form-group">
            <div className="controls">
              <input type="hidden" className="form-control" id="subject" placeholder="Full Name" value="Value Plus/Home page/Lets get started" required data-validation-required-message="Please enter your name." />

              <input type="text" className="form-control" id="name" placeholder="Full Name" required data-validation-required-message="Please enter your name." />
              <p className="help-block"></p>
            </div>
          </div>
          <div className="control-group form-group">
            <div className="controls">

              <input type="email" className="form-control" id="email" placeholder=" Email Id" required data-validation-required-message="Please enter your email address." />
            </div>
          </div>
          <div className="row">

            <div className="col-lg-6" style={{width:'110px'}}>
              <div className="control-group form-group">
                <div className="controls">

                  <input type="tel" className="form-control" id="phone" placeholder="Contact No" required data-validation-required-message="Please enter your phone number." />
                </div>
              </div>

            </div>
            <div className="col-lg-6" style= {{width:'110px'}}>
              <div className="control-group form-group">
                <div className="controls">

                  <input type="text" className="form-control" id="city" placeholder="City Name" required data-validation-required-message="Please enter your city name."/>
                </div>
              </div>
            </div>
          </div>
          <div className=" control-group form-group">
            <label for="sel1" className="dialoguetext" style={{color:'#585858'}}>Type of entity :</label>
            <select className="form-control" id="typeOfEntity" placeholder="Type of entity">
                                      <option>Privated Limited Company</option>
                                      <option>Public limited Company</option>
                                      <option>One Person Company</option>
                                      <option>Limited Liability Partnership</option>
                                      <option>Partnership</option>
                                      <option>Section 8 company/NGO</option>
                                      <option>Trust</option>
                                      <option>Society</option>
                                      <option>NBFC</option>
                                    </select>
          </div>

          <div className="row">

            <div className="col-lg-6"  style={{ width:'110px'}}>
              <div className=" control-group form-group">
                <label for="sel1" className="dialoguetext">Select Product :</label>
                <select className="form-control" id="product" onChange={this.filterproduct} >
                {this.state.product.map((pc)=>{
                  return <option value={pc.productId} key={pc.productId}> {pc.name} </option>;
                })}
                                    </select>
              </div>
            </div>
            <div className="col-lg-6" style={{ width:'110px'}}>
              <div className=" control-group form-group">
                <label for="sel1" className="dialoguetext">Product Category :</label>
                <select className="form-control" id="productCategory">
                                            
                                           {this.state.filteredCategory.map((pc,index)=>{
                                             return <option key={index}> {pc.name} </option>;
                                           })}


                                        </select>
              </div>
            </div>
          </div>

          <div id="success"></div>
          {/*For success/fail messages*/}
          <button type="submit" className="btn btn-primary heading6" id="sendMessageButton" style={{ width:'334px'}}>Submit</button>
        </form>
      </div>
    );
  }
}

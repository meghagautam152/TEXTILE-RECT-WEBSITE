export const sitemap = [

    {
        title: "Products",
        childs: [{

                link: "../products/comply+",
                title: "Comply +"

            },
            {

                link: "../products/windup+",
                title: "Windup +"

            }


        ]
    },
    {
        title: "Consultings",
        childs: [{

                link: "../products/corporate+",
                title: "corporate +"

            },
            {

                link: "../consulting/Startup+",
                title: "Startup +"

            }


        ]
    }



]